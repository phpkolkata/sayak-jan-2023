<?php
require("lib/session_security.php");

require("db.php");

$id = $_REQUEST['id'];
$sql = "select * from `category` where `id` = '$id'";
$res = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($res);


?>

<form action="editing-cat.php" method="post">

<input type="hidden" name="cid" value="<?php echo $row['id'] ?>" >
Name: <input type="text" name="nm" value="<?php 
        echo $row['name']?>"><br>
isActive: <input type="radio" name="isActive" value="y" <?php echo ($row['is_active'] == "y")? "checked='checked'":"";?> > Yes 
 <input type="radio" name="isActive" value="n" <?php echo ($row['is_active'] == "n")? "checked='checked'":"";?>> 
 No
 <input type="submit" value="Update"> 
</form>