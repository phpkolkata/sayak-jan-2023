<?php 
require("lib/session_security.php");

require("db.php");

extract($_POST);

$sql = "update `category` set `name`='$nm', `is_active`='$isActive' where `id`='$cid'";
$res = mysqli_query($con, $sql);
header("location:category.php?msg=record updated successfully!");