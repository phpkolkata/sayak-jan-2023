<?php
$con = mysqli_connect("localhost","asif","asif","mobile_store");
if(!$con){

	die("connection error");
}

