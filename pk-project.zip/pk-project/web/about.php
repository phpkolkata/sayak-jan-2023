<?php
require("includes/header.php");
?>

		    	<div class="about">
		    		<h4>About Us</h4>
		    		<div class="section group">
					<div class="col_1_of_3 span_1_of_3 about-frist">
						<h3>Did You Know?</h3>
						<h5>volutpat a enim. Vivamus blandit urna </h5>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
						<ul>
							<li><a href="#">Aenean nonummy hendrerit</a></li>
							<li><a href="#">consectetur adipisicing elit</a></li>
							<li><a href="#">tempor incididunt ut labore</a></li>
							<li><a href="#">Ut enim ad minim veniamt</a></li>
							<li><a href="#">Vivamus blandit urna</a></li>
							<li><a href="#">Lorem ipsum dolor sit amet</a></li>
							<li><a href="#">Ut enim ad minim veniam</a></li>
							<li><a href="#">Vivamus blandit urna</a></li>
							<li><a href="#">Lorem ipsum dolor sit amet</a></li>
							<li><a href="#">Ut enim ad minim veniam</a></li>
						</ul>
					</div>
					<div class="col_1_of_3 span_1_of_3 about-centre">
						<h3>Our Mission</h3>
						<a href="#"><img src="images/grid-img2.jpg"></a>
						<h5>Lorem ipsum dolor sit amet, consectetur adipisicing elitvolutpat a enim. Vivamus blandit urna </h5>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
					</div>
					<div class="col_1_of_3 span_1_of_3 quites">
						<h3>Testimonials</h3>
						<blockquote><p><img src="images/quotes_alt.png"> &nbsp;Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p></blockquote>
						<a href="#">- Lorem ipsum.<span>Usa</span></a><br /><br />
						<blockquote><p><img src="images/quotes_alt.png"> &nbsp;Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p></blockquote>
						<a href="#">- Lorem ipsum.<span>Usa</span></a>
					</div>
					<div class="clear"> </div>
					<div class="section group">
						<div class="cont span_2_of_3">
						       <h3>Mobile-store General Information</h3>
							   	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
							   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
						       <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>				    
						</div>
						<div class="rsidebar span_1_of_3 about-frist">
						      <h3>Fresh-links</h3>
						      <ul>
								<li><a href="#">Aenean nonummy hendrerit</a></li>
								<li><a href="#">consectetur adipisicing elit</a></li>
								<li><a href="#">tempor incididunt ut labore</a></li>
								<li><a href="#">Ut enim ad minim veniamt</a></li>
								<li><a href="#">Vivamus blandit urna</a></li>
								<li><a href="#">Lorem ipsum dolor sit amet</a></li>
								<li><a href="#">Ut enim ad minim veniam</a></li>
								<li><a href="#">Vivamus blandit urna</a></li>
								<li><a href="#">Lorem ipsum dolor sit amet</a></li>
								<li><a href="#">Ut enim ad minim veniam</a></li>
							</ul>
						      
						</div>
		    </div>
				</div>
				
		    	</div>
		    	</div>
		    	
		    </div>
<?php

require("includes/footer.php");